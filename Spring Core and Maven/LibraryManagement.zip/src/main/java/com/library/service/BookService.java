package com.library.service;
import com.library.repository.BookRepository;
public class BookService{
 private BookRepository bookRepository;
 public void setBookRepository(BookRepository b){this.bookRepository=b;}
 public void displayService(){System.out.println("Book Service");bookRepository.displayRepository();}
}