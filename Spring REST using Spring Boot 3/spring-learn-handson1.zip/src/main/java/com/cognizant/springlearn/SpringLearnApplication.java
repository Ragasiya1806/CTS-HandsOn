package com.cognizant.springlearn;
import org.slf4j.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class SpringLearnApplication{
private static final Logger LOGGER=LoggerFactory.getLogger(SpringLearnApplication.class);
public static void main(String[] args){
LOGGER.info("START");
SpringApplication.run(SpringLearnApplication.class,args);
LOGGER.info("END");
}
}
