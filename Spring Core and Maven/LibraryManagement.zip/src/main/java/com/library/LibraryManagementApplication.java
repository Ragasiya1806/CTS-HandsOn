package com.library;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.library.service.BookService;
public class LibraryManagementApplication{
 public static void main(String[] args){
 ApplicationContext c=new ClassPathXmlApplicationContext("applicationContext.xml");
 BookService s=c.getBean("bookService",BookService.class);
 s.displayService();
 }
}