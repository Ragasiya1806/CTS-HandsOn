package com.library;
import org.springframework.context.*;import org.springframework.context.support.*;import com.library.service.BookService;
public class LibraryManagementApplication{public static void main(String[]a){ApplicationContext c=new ClassPathXmlApplicationContext("applicationContext.xml");c.getBean(BookService.class).displayService();}}