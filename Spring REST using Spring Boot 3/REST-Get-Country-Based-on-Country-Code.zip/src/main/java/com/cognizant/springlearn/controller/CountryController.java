
package com.cognizant.springlearn.controller;
import org.springframework.web.bind.annotation.*;
import com.cognizant.springlearn.Country;
import com.cognizant.springlearn.service.CountryService;
@RestController
public class CountryController{
private final CountryService service;
public CountryController(CountryService service){this.service=service;}
@GetMapping("/countries/{code}")
public Country getCountry(@PathVariable String code){
return service.getCountry(code);
}
}
